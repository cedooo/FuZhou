/*
 * Copyright (c) 2007-2011, Hangzhou H3C Technologies Co., Ltd. All rights reserved.
 * <http://www.h3c.com/>
 *------------------------------------------------------------------------------
 * Product     : iMC V500R001
 * Module Name :
 * Date Created: 2011-4-18
 * Creator     : l01010
 * Description :
 *
 *------------------------------------------------------------------------------
 * Modification History
 * DATE        NAME             DESCRIPTION
 *------------------------------------------------------------------------------
 * 2011-4-18  l01010             XXXX project, new code file.
 *
 *------------------------------------------------------------------------------
 */

package com.h3c.imc.rs.ext.event;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertTrue;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.params.HttpConnectionManagerParams;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.params.ClientPNames;
import org.apache.http.client.utils.URIUtils;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.junit.Test;

import com.h3c.imc.rs.client.TrustAnyTrustManager;
import com.h3c.imc.rs.ext.event.SampleEventProvider.SampleEntity;

/**
 * ���� Server Push �¼���
 */
public class ServerPushEventTest {

    /**
     * ���� {@link EventClient}��
     *
     * @throws Exception ���Թ��̳�����
     */
    @Test
    public void testEventClient() throws Exception {
        EventClient<SampleEntity> client = new EventClient<SampleEntity>(
            new URL("http://localhost:8080/imcrs/events?type=1&subType=sample"),
            SampleEntity.class) {
            @Override
            public void onMessage(SampleEntity entity) {
                System.out.println("On Message: " + entity.getTime());
            }
            @Override
            public void onError(Throwable t) {
                System.out.println("ERROR");
                t.printStackTrace();
            }
        };
        assertTrue(client.start());
        Thread.sleep(15000L);
        client.stop();
    }

    /**
     * ʹ�û����� HttpURLConnection ���в��ԡ�
     *
     * @throws Exception ���Թ��̳�����
     */
    @Test
    public void testSampleEvent() throws Exception {
        URL url = new URL("http://10.153.89.89:8080/imcrs/events?type=11&uuid=abcdefg");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setRequestProperty("accept", "application/xml");
        System.out.println(conn.getResponseCode());
        assertEquals(202, conn.getResponseCode());
        System.out.println("Content-Type: " + conn.getContentType());
        System.out.println(conn.getHeaderFields());
        BufferedReader br = new BufferedReader(new InputStreamReader(
            conn.getInputStream()));
        String line = null;
        // ����һ����Ϣ���˳�
        while ((line = br.readLine()) != null) {
            System.out.println(line);
//            if (line.length() == 0) {
//                break;
//            }
        }
        conn.disconnect();
    }

    /**
     * ʹ�� Commons Http Client ���в��ԡ�
     *
     * @throws Exception ���Թ��̳�����
     */
    @Test
    public void testCommonsClient() throws Exception {
        HttpClient client = new HttpClient();
        HttpConnectionManagerParams params =
            client.getHttpConnectionManager().getParams();
        params.setConnectionTimeout(5000);
        params.setSendBufferSize(8192);
        params.setReceiveBufferSize(8192);
        // ʹ�� HTTP ����
        client.getHostConfiguration().setHost("localhost", 8080);
        client.getState().setCredentials(
            new org.apache.commons.httpclient.auth.AuthScope("localhost", 8080,
                "iMC RESTful Web Services"),
            new org.apache.commons.httpclient.UsernamePasswordCredentials("admin", "admin"));
        // GET ����
        GetMethod get = new GetMethod("/imcrs/events");
        get.addRequestHeader("accept", "application/xml");
        get.setQueryString(new org.apache.commons.httpclient.NameValuePair[] {
            new org.apache.commons.httpclient.NameValuePair("type", "1"),
            new org.apache.commons.httpclient.NameValuePair("subType", "sample")});
        assertEquals(HttpStatus.SC_ACCEPTED, client.executeMethod(get));
        BufferedReader br = new BufferedReader(
            new InputStreamReader(get.getResponseBodyAsStream()));
        String line = br.readLine();
        // ����һ����Ϣ���˳�
        int k = 0;
        int count = 1;
        while (line != null && k < count) {
            System.out.println(line);
            line = br.readLine();
            k++;
        }
        // get.releaseConnection();
        client.getHttpConnectionManager().closeIdleConnections(0);
    }

    /**
     * ʹ�� Http Client ���в��ԡ�
     *
     * @throws Exception ���Թ��̳�����
     */
    @Test
    public void testHttpClient() throws Exception {
        // ͬʱ֧�� http �� https
        SSLContext sc = SSLContext.getInstance("TLS");
        sc.init(null, new TrustManager[] { new TrustAnyTrustManager() }, null);
        SchemeRegistry registry = new SchemeRegistry();
        registry.register(new Scheme("http", 8080, PlainSocketFactory.getSocketFactory()));
        registry.register(new Scheme("https", 8443, new SSLSocketFactory(sc,
            SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER)));
        ClientConnectionManager ccm = new ThreadSafeClientConnManager(registry);
        DefaultHttpClient client = new DefaultHttpClient(ccm);
        HttpHost defaultHost = new HttpHost("localhost", 8080, "http");

        HttpParams params = client.getParams();
        HttpConnectionParams.setConnectionTimeout(params, 5000);
        HttpConnectionParams.setSocketBufferSize(params, 8192);
        params.setParameter(ClientPNames.DEFAULT_HOST, defaultHost);

        // ��֤��Ϣ
        client.getCredentialsProvider().setCredentials(
            new AuthScope("localhost", 8080, "iMC RESTful Web Services"),
            new UsernamePasswordCredentials("admin", "admin"));
        client.getCredentialsProvider().setCredentials(
            new AuthScope("localhost", 8443, "iMC RESTful Web Services"),
            new UsernamePasswordCredentials("admin", "admin"));

        List<NameValuePair> qparams = new ArrayList<NameValuePair>();
        qparams.add(new BasicNameValuePair("type", "1"));
        qparams.add(new BasicNameValuePair("subType", "sample"));
        HttpGet get = new HttpGet(URIUtils.createURI(defaultHost.getSchemeName(),
            defaultHost.getHostName(), defaultHost.getPort(),
            "/imcrs/events", URLEncodedUtils.format(qparams, "UTF-8"), null));
        get.addHeader("accept", "application/xml");
        HttpResponse response = client.execute(get);
        assertEquals(HttpStatus.SC_ACCEPTED, response.getStatusLine().getStatusCode());
        BufferedReader br = new BufferedReader(
            new InputStreamReader(response.getEntity().getContent()));
        String line = br.readLine();
        // ����һ����Ϣ���˳�
        int k = 0;
        int count = 1;
        while (line != null && k < count) {
            System.out.println(line);
            line = br.readLine();
            k++;
        }
        get.abort();
        client.getConnectionManager().shutdown();
    }
}
